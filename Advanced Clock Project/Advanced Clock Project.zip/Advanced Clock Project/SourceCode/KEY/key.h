#ifndef __KEY_H
#define __KEY_H

#include "stm32f4xx.h"

void KEY_Init(void);
void KEYService(void);

#endif



