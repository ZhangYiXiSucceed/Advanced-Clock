#ifndef __IWDG_H__
#define __IWDG_H__

#include "stm32f4xx.h"

void IWDG_Init(void);
void IWDG_Feed(void);


#endif



